<template src="./src.html"> </template>

<script>
import { mapState, mapGetters, mapActions } from 'vuex'
import api from "../../api"
import { formClean } from "../../common/util"
import validate from "../../common/validate"
import store from "../../store"

export default {
  name: 'src',
  data () {
    return {
      formData: { status: '', system: '' },
      tableData: [
        { name: '', url: '', type: '', parent: '', sort: '', status: '', },
      ],
      formOption: { SYS_RESOURCE_TYPE: [], system_parent: [], system: [], urlVisible: false},
      dialog: {
        create: {
          visible: false,
          urlVisible: false,
          formData: { name: '', status: '', type: '', url: '', parent: '',
                      system: '', system_parent: [], code: '', sort: '', },
          formRules: {
            name: validate.required,
            status: validate.required,
            type: validate.required,
            parent: validate.required,
            system: validate.required,
            code: validate.required,
          },
        },
        edit: {
          visible: false,
          dirty: false,
          formData: { name: '', status: '', type: '', url: '', parent: '',
                      system: '', code: '', sort: '', id: '', combin: []},
          formRules: {
            name: validate.required,
            status: validate.required,
            type: validate.required,
            parent: validate.required,
            system: validate.required,
          },
        },
        child: {
          visible: false,
          formData: { name: '', status: '', type: '', url: '', parent: '',
                      system: '', code: '', sort: '', },
          formRules: {
            name: validate.required,
            status: validate.required,
            type: validate.required,
            parent: validate.required,
            system: validate.required,
          },
        },
      }
    }
  },
  computed: {
    createFormValid() {
      const form = this.dialog.create.formData
      return form.name && form.status && form.type && form.system ;
    },
    editFormValid() {
      const form = this.dialog.edit.formData
      return form.name && form.status && form.type &&
              form.system && this.dialog.edit.dirty;
    },
    createChildFormValid() {
      const form = this.dialog.child.formData
      return form.name && form.status && form.type && form.parent && form.system ;
    },
  },
  beforeRouteEnter (to, from, next) {
    let src = [], system = [], _SYS_RESOURCE_TYPE = []
    const syscode = api.common.adminsys()
    const SYS_RESOURCE_TYPE = api.common.dic_group('SYS_RESOURCE_TYPE')
    const reqPre = Promise.all([syscode, SYS_RESOURCE_TYPE])

    reqPre.then( res => {
      system = res[0]
      _SYS_RESOURCE_TYPE = res[1][0]['childs']
      return res[0].map( v => {
        src.push({label: v.systemName, value: v.systemCode})
        return api.common.sysrescource_tree(v.systemCode)
      })
    }).then( res => {
      Promise.all(res).then( resp => {
        for (var i = 0; i < src.length; i++) {
          if (resp[i].length > 0) {
            src[i]['children'] = resp[i].map( v => {
              return {label: v.name, value: v.id}
            })
          }
        }
      })
      return src
    }).then( res => {
      next(vm => {
        vm.formOption.system = system
        vm.formOption.system_parent = res
        vm.formOption.SYS_RESOURCE_TYPE = _SYS_RESOURCE_TYPE
      })
    })
  },
  created() {
    this.init()
  },
  methods: {
    init(param = {}) {
      api.src.sysrescource_page({
        available: param.status,
        name: param.system
      }).then( res => {
        this.tableData = res.records
      })
    },
    getSrc(id) {
      const form = this.dialog.edit.formData
      let p = api.src.sysrescource_get(id).then( res => {
        form.id = res.id
        form.name = res.name
        form.status = res.available
        form.type = res.type
        form.combin = [ res.systemCode, res.parentId ]
        form.system = res.systemCode
        form.parent = res.parentId
        form.sort = res.seq
        form.url = res.url
        form.code = res.permission

        this.onEditCheckType()
        return Promise.resolve()
      })
      return Promise.resolve(p)
    },
    onCreateCheckType() {
      this.formOption.urlVisible = false
      for (let v of this.formOption.SYS_RESOURCE_TYPE) {
        if (this.dialog.create.formData.type == v.dicCode &&
          ['菜单', '链接'].indexOf(v.display) != -1) {
            this.formOption.urlVisible = true
          }
        }
    },
    onEditCheckType() {
      this.formOption.urlVisible = false
      for (let v of this.formOption.SYS_RESOURCE_TYPE) {
        if (this.dialog.edit.formData.type == v.dicValue &&
          ['菜单', '链接'].indexOf(v.display) != -1) {
            this.formOption.urlVisible = true
          }
        }
    },
    onCheckType(target) { //检查类型
    },
    onSearch() {

    },
    onCreateOpen() {
      this.dialog.create.visible = true
    },
    createClose() {
      this.dialog.create.formData = formClean(this.dialog.create.formData)
    },
    onCreateSubmit() {
      const form = this.dialog.create.formData
      api.src.sysrescource({
        id: form.id,
        name: form.name,
        available: form.status,
        type: form.type,
        parentId: form.parent,
        systemCode: form.system,
        permission: form.code,
        url: form.url,
        seq: form.sort,
      }).then( res => {
        this.$notify({
          title: '创建成功',
          type: 'success',
          duration: 2000
        });
        this.dialog.create.visible = false
      })
    },
    dialogOpen(ref) {
      if (ref in this.$refs) {
        this.$refs[ref].clearValidate();
      }
    },
    onEditOpen(id) {
      this.getSrc(id).then( () => {
        this.dialog.edit.visible = true
      })
    },
    onSelectChange(value) {
      const form = this.dialog.edit.formData
      form.system = value[0]
      form.parent = value[1] || ''
    },
    onEditSubmit() {
      const form = this.dialog.edit.formData
      api.src.sysrescource_put({
        id: form.id,
        available: form.status,
        name: form.name,
        parentId: form.parent,
        permission: form.code,
        seq: form.sort,
        systemCode: form.system,
        type: form.type,
        url: form.url
      }).then( res => {
        this.$notify({
          title: '修改成功',
          type: 'success',
          duration: 2000
        });
        this.dialog.edit.visible = false
        this.init({
          available: this.formData.status,
          name: this.formData.system
          })
      })
    },
    onEditFormValidate() { this.dialog.edit.dirty = true },
    editClose() {
      this.dialog.edit.formData = formClean(this.dialog.edit.formData)
      this.dialog.edit.dirty = false
    },
    onChildOpen() {
      this.dialog.child.visible = true
    },
    childClose() {
      this.dialog.child.formData = formClean(this.dialog.child.formData)
    },
  }
}
</script>
