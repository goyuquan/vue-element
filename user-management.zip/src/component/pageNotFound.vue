<template>
  <div>
    <h1>Page Not found</h1>
  </div>
</template>

<script>
export default {
  name: 'pageNotFound'
}
</script>

<style lang="scss" scoped>
  div {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 600px;
  }
</style>
