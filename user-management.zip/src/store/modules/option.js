import api from '../../api'

const state = {
  dictionary: {
    adminsys: [],
    dic_group: [],
    sysrescource_tree: {},
    SYS_RESOURCE_TYPE: []
  }
}

const getters = {

}

const mutations = {
  fetch(state, payload) {
    if ('node' in payload) {
      state.dictionary[payload.name.name][payload.node] = payload.res
    } else {
      state.dictionary[payload.name.name] = payload.res
    }
  },
}


const actions = {

  fetch({ commit, state }, payload) {
      return Promise.resolve(
        api.common[payload.name](payload.param).then( res => {
          return Promise.resolve(res)
        })
      )
  },


}


export default { state, getters, actions, mutations }
